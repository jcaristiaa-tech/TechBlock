# 3D Cube FEA — Linear Elasticity

Proyecto mínimo de elementos finitos (FEA) para un cubo sólido de **1 m × 1 m × 1 m** sometido a una presión normal de **1 MPa** sobre la cara `x = 1 m`.

## Importante: dato faltante

Para obtener desplazamientos absolutos hace falta el **módulo de Young E** y el **coeficiente de Poisson ν**. "Isotrópico" y un límite elástico de 800 MPa no determinan E ni ν.

Por eso el ejemplo incluye valores explícitos y editables:
- `E = 210 GPa`
- `nu = 0.30`
- `yield_strength = 800 MPa`

Con esos valores, el análisis es lineal-elástico y la presión es suficientemente pequeña para mantenerse por debajo del yield.

## Qué hace

- Genera una malla estructurada hexaédrica de 8 nodos por elemento.
- Ensambla la matriz global de rigidez 3D.
- Aplica presión distribuida de 1 MPa en `x = 1`.
- Fija la cara `x = 0` en las tres direcciones.
- Resuelve `K u = f`.
- Calcula el desplazamiento `(ux, uy, uz)` de **cada nodo**.
- Escribe resultados en CSV y VTK.
- Calcula von Mises nodal aproximado a partir de tensiones de los elementos.

> Nota física: "después de un minuto" no cambia el resultado porque este modelo es estático, lineal-elástico y no tiene masa, amortiguamiento ni dependencia temporal. Si quieres una respuesta a 60 s real, hay que definir densidad y un modelo dinámico/viscoelástico.

## Instalación en macOS

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## Ejecutar

```bash
python -m src.cube_fea
```

O con otra malla:

```bash
python -m src.cube_fea --nx 4 --ny 4 --nz 4
```

Los resultados aparecen en `results/`.

## Visualización

El archivo `results/cube_displacement.vtk` se puede abrir con ParaView.

## Estructura

```text
cube_fea/
├── src/
│   ├── __init__.py
│   └── cube_fea.py
├── results/
├── requirements.txt
├── .gitignore
└── README.md
```
