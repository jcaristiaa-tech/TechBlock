import argparse
from pathlib import Path

import meshio
import numpy as np
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import spsolve


def hex8_shape_derivatives(xi, eta, zeta):
    """Derivatives of the 8 trilinear Hex8 shape functions."""
    signs = np.array([
        [-1, -1, -1], [1, -1, -1], [1, 1, -1], [-1, 1, -1],
        [-1, -1,  1], [1, -1,  1], [1, 1,  1], [-1, 1,  1],
    ], dtype=float)

    dN = np.empty((8, 3))
    for a, (sx, sy, sz) in enumerate(signs):
        dN[a, 0] = 0.125 * sx * (1 + sy * eta) * (1 + sz * zeta)
        dN[a, 1] = 0.125 * sy * (1 + sx * xi) * (1 + sz * zeta)
        dN[a, 2] = 0.125 * sz * (1 + sx * xi) * (1 + sy * eta)
    return dN


def elasticity_matrix(E, nu):
    """3D isotropic constitutive matrix in [xx,yy,zz,xy,yz,xz] Voigt form."""
    lam = E * nu / ((1 + nu) * (1 - 2 * nu))
    mu = E / (2 * (1 + nu))

    D = np.array([
        [lam + 2*mu, lam, lam, 0, 0, 0],
        [lam, lam + 2*mu, lam, 0, 0, 0],
        [lam, lam, lam + 2*mu, 0, 0, 0],
        [0, 0, 0, mu, 0, 0],
        [0, 0, 0, 0, mu, 0],
        [0, 0, 0, 0, 0, mu],
    ])
    return D


def hex8_stiffness(coords, D):
    """Element stiffness with 2x2x2 Gauss integration."""
    gp = 1.0 / np.sqrt(3.0)
    points = [(-gp, -gp, -gp), (gp, -gp, -gp), (gp, gp, -gp), (-gp, gp, -gp),
              (-gp, -gp, gp), (gp, -gp, gp), (gp, gp, gp), (-gp, gp, gp)]

    Ke = np.zeros((24, 24))
    for xi, eta, zeta in points:
        dN_dnatural = hex8_shape_derivatives(xi, eta, zeta)
        J = dN_dnatural.T @ coords
        detJ = np.linalg.det(J)
        if detJ <= 0:
            raise ValueError(f"Non-positive Jacobian determinant: {detJ}")
        dN_dx = dN_dnatural @ np.linalg.inv(J)

        B = np.zeros((6, 24))
        for a in range(8):
            ix = 3 * a
            dNx, dNy, dNz = dN_dx[a]
            B[0, ix]     = dNx
            B[1, ix + 1] = dNy
            B[2, ix + 2] = dNz
            B[3, ix]     = dNy
            B[3, ix + 1] = dNx
            B[4, ix + 1] = dNz
            B[4, ix + 2] = dNy
            B[5, ix]     = dNz
            B[5, ix + 2] = dNx

        Ke += B.T @ D @ B * detJ
    return Ke


def make_mesh(nx, ny, nz, L=1.0):
    """Structured Hex8 mesh of a cube."""
    xs = np.linspace(0, L, nx + 1)
    ys = np.linspace(0, L, ny + 1)
    zs = np.linspace(0, L, nz + 1)

    def nid(i, j, k):
        return k * (ny + 1) * (nx + 1) + j * (nx + 1) + i

    points = np.array([(x, y, z) for z in zs for y in ys for x in xs])
    hexes = []
    for k in range(nz):
        for j in range(ny):
            for i in range(nx):
                hexes.append([
                    nid(i, j, k), nid(i+1, j, k), nid(i+1, j+1, k), nid(i, j+1, k),
                    nid(i, j, k+1), nid(i+1, j, k+1), nid(i+1, j+1, k+1), nid(i, j+1, k+1)
                ])
    return points, np.asarray(hexes, dtype=int)


def face_pressure_load(points, nx, ny, nz, pressure):
    """Consistent nodal load on x=L face for pressure acting +x."""
    # Bilinear quad integration over each surface element.
    f = np.zeros(3 * len(points))
    dx = 1.0 / nx
    dy = 1.0 / ny

    def nid(i, j, k=0):
        return k * (ny + 1) * (nx + 1) + j * (nx + 1) + i

    # Face x=1, oriented so traction is +x.
    for j in range(ny):
        for k in range(nz):
            n = [nid(nx, j, k), nid(nx, j+1, k),
                 nid(nx, j+1, k+1), nid(nx, j, k+1)]
            area = dx * (1.0 / nz)
            # Exact consistent load for constant traction on bilinear quad:
            for node in n:
                f[3*node] += pressure * area / 4.0
    return f


def von_mises(stress):
    sxx, syy, szz, txy, tyz, txz = stress
    return np.sqrt(
        0.5 * ((sxx-syy)**2 + (syy-szz)**2 + (szz-sxx)**2)
        + 3.0 * (txy**2 + tyz**2 + txz**2)
    )


def solve(nx=2, ny=2, nz=2, E=210e9, nu=0.30, pressure=1e6,
          yield_strength=800e6, outdir="results"):
    L = 1.0
    points, hexes = make_mesh(nx, ny, nz, L)
    nnode = len(points)
    ndof = 3 * nnode
    D = elasticity_matrix(E, nu)

    K = lil_matrix((ndof, ndof))
    for elem in hexes:
        dofs = np.array([3*n + d for n in elem for d in range(3)])
        Ke = hex8_stiffness(points[elem], D)
        for a in range(24):
            for b in range(24):
                K[dofs[a], dofs[b]] += Ke[a, b]

    f = face_pressure_load(points, nx, ny, nz, pressure)

    # Clamp x=0 face: ux=uy=uz=0.
    fixed_nodes = np.where(np.isclose(points[:, 0], 0.0))[0]
    fixed = np.array([3*n+d for n in fixed_nodes for d in range(3)], dtype=int)
    free = np.setdiff1d(np.arange(ndof), fixed)

    K = K.tocsr()
    u = np.zeros(ndof)
    u[free] = spsolve(K[free][:, free], f[free])

    U = u.reshape((-1, 3))
    displacement_mag = np.linalg.norm(U, axis=1)

    # Element-center stress; then average to nodes for a simple nodal field.
    nodal_stress = np.zeros((nnode, 6))
    counts = np.zeros(nnode)
    for elem in hexes:
        dN = hex8_shape_derivatives(0, 0, 0)
        J = dN.T @ points[elem]
        dN_dx = dN @ np.linalg.inv(J)
        B = np.zeros((6, 24))
        for a in range(8):
            ix = 3*a
            dNx, dNy, dNz = dN_dx[a]
            B[0, ix] = dNx
            B[1, ix+1] = dNy
            B[2, ix+2] = dNz
            B[3, ix] = dNy; B[3, ix+1] = dNx
            B[4, ix+1] = dNz; B[4, ix+2] = dNy
            B[5, ix] = dNz; B[5, ix+2] = dNx

        ue = u[np.array([3*n+d for n in elem for d in range(3)])]
        stress = D @ B @ ue
        for n in elem:
            nodal_stress[n] += stress
            counts[n] += 1

    nodal_stress /= counts[:, None]
    vm = np.array([von_mises(s) for s in nodal_stress])

    out = Path(outdir)
    out.mkdir(parents=True, exist_ok=True)

    csv = out / "nodal_displacements.csv"
    with csv.open("w") as fp:
        fp.write("node,x_m,y_m,z_m,ux_m,uy_m,uz_m,umag_m,von_mises_Pa\n")
        for i, ((x,y,z), (ux,uy,uz), um, v) in enumerate(
            zip(points, U, displacement_mag, vm)
        ):
            fp.write(f"{i},{x:.12g},{y:.12g},{z:.12g},{ux:.12g},{uy:.12g},{uz:.12g},{um:.12g},{v:.12g}\n")

    vtk = out / "cube_displacement.vtk"
    meshio.write_points_cells(
        vtk,
        points,
        [("hexahedron", hexes)],
        point_data={
            "ux_m": U[:, 0],
            "uy_m": U[:, 1],
            "uz_m": U[:, 2],
            "displacement_m": displacement_mag,
            "von_mises_Pa": vm,
        },
    )

    max_i = int(np.argmax(displacement_mag))
    max_vm = float(vm.max())

    print(f"Nodes: {nnode}")
    print(f"Elements: {len(hexes)}")
    print(f"Max displacement: {displacement_mag[max_i]:.6e} m")
    print(f"At node: {max_i}, coordinates = {points[max_i]}")
    print(f"Max nodal von Mises: {max_vm/1e6:.6f} MPa")
    print(f"Yield strength: {yield_strength/1e6:.3f} MPa")
    print(f"Factor vs yield (using max nodal von Mises): {yield_strength/max_vm:.3f}")
    print(f"Results: {csv}")
    print(f"VTK:     {vtk}")

    return points, hexes, U, vm


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--nx", type=int, default=2)
    p.add_argument("--ny", type=int, default=2)
    p.add_argument("--nz", type=int, default=2)
    p.add_argument("--E", type=float, default=210e9,
                   help="Young modulus in Pa")
    p.add_argument("--nu", type=float, default=0.30,
                   help="Poisson ratio")
    p.add_argument("--pressure", type=float, default=1e6,
                   help="Pressure in Pa")
    p.add_argument("--yield-strength", type=float, default=800e6,
                   help="Yield strength in Pa")
    args = p.parse_args()

    solve(args.nx, args.ny, args.nz, args.E, args.nu,
          args.pressure, args.yield_strength)


if __name__ == "__main__":
    main()
